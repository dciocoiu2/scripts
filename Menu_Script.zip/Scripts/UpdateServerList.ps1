Function Connect-RemoteServer {
    param (
        [string]$RemoteServer,
        [string]$Username,
        [string]$Password,
        [string]$Domain,
        [string]$SharedFolder
    )

    # Create a credential object
    $Credential = New-Object System.Management.Automation.PSCredential -ArgumentList $Username, $(ConvertTo-SecureString $Password -AsPlainText -Force)

    # Create a remote session to the server
    $Session = New-PSSession -ComputerName $RemoteServer -Credential $Credential

    # Import the remote session
    Import-PSSession $Session -AllowClobber

    # Define the script to run on the remote server
    $Script = {
        Get-ADComputer -Filter {Name -like "*"} -SearchBase "OU=Servers,DC=$Domain" | Select-Object Name | Out-String
    }

    # Run the script on the remote server and save the output to a text file on the shared folder
    Invoke-Command -Session $Session -ScriptBlock $Script | Out-File "$SharedFolder\ServerList.txt"

    # Remove the remote session
    Remove-PSSession $Session
}