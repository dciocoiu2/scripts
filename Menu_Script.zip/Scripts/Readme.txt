Run PS in a different domain

>runas /netonly /user:domain\username "%windir%\system32\WindowsPowerShell\v1.0\PowerShell_ISE.exe"

Follow the steps below

1. Create list of serves as a TXT file called Servers.txt
2. Run the Powershell script - ListServerUpdates.ps1
	Two files will be generated - Updates.csv and Errors.csv
3. Import Updates.csv in Excel
	Open Excel
	Go to Data tab
	Click "From Text/CSV"
	Validate the columns in the import wizard look good
	Click Load
	Select all cells in the InstalledOn column
	Go to Home
	Click "Conditional formatting"
	Select "Hilglight Cells Rules"-->"Less Than"
	Enter a date to highlight the cells less than the value entered
	Save the file
	
	