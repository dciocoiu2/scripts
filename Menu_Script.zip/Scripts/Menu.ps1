﻿[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
 
# form specs
$objForm = New-Object System.Windows.Forms.Form
$objForm.Text = "Check Network Status"
$objForm.Size = New-Object System.Drawing.Size(400,200)
$objForm.StartPosition = "CenterScreen"
$objForm.KeyPreview = $True
$objForm.MaximumSize = $objForm.Size
$objForm.MinimumSize = $objForm.Size
 
# form icon
$objIcon = New-Object system.drawing.icon ("C:\Temp\Scripts\form.ico")
$objForm.Icon = $objIcon
# form background
$objImage = [system.drawing.image]::FromFile("C:\Temp\Scripts\form_background.jpg")
$objForm.BackgroundImage = $objImage
$objForm.BackgroundImageLayout = "None"
# None, Tile, Center, Stretch, Zoom
 
$objForm.Width = $objImage.Width
$objForm.Height = $objImage.Height
 
# domain label
$objLabel = New-Object System.Windows.Forms.label
$objLabel.Location = New-Object System.Drawing.Size(7,10)
$objLabel.Size = New-Object System.Drawing.Size(130,15)
$objLabel.BackColor = "Transparent"
$objLabel.ForeColor = "yellow"
$objLabel.Text = "Domain Name"
$objForm.Controls.Add($objLabel)

# action label
$objLabel = New-Object System.Windows.Forms.label
$objLabel.Location = New-Object System.Drawing.Size(140,10)
$objLabel.Size = New-Object System.Drawing.Size(130,15)
$objLabel.BackColor = "Transparent"
$objLabel.ForeColor = "yellow"
$objLabel.Text = "Action "
$objForm.Controls.Add($objLabel)

#list of domains 
$listBoxDomain = New-Object System.Windows.Forms.ListBox
$listBoxDomain.Location = New-Object System.Drawing.Point(10,30)
$listBoxDomain.Size = New-Object System.Drawing.Size(120,20)
$listBoxDomain.Height = 60
$objForm.Controls.Add($listBoxDomain)
# add items
[void] $listBoxDomain.Items.Add('ymposmaster')
[void] $listBoxDomain.Items.Add('posstoremaster')
[void] $listBoxDomain.Items.Add('stitchesmaster')
# hash to identify the jump servers for each enironment/domain
$domainHash = @{
    'ymposmaster' = '192.168.1.1' 
    'posstoremaster' = '192.168.1.2'
    'stitchesmaster' = '192.168.1.3'
}

#list of actions 
$listBoxAct = New-Object System.Windows.Forms.ListBox
$listBoxAct.Location = New-Object System.Drawing.Point(140,30)
$listBoxAct.Size = New-Object System.Drawing.Size(135,20)
$listBoxAct.Height = 60
$objForm.Controls.Add($listBoxAct)
# add items
[void] $listBoxAct.Items.Add('Local Admins & RDP Users')
[void] $listBoxAct.Items.Add('Window Updates')
[void] $listBoxAct.Items.Add('=========================')
[void] $listBoxAct.Items.Add('View Report')

# username label
$objLabelUser = New-Object System.Windows.Forms.label
$objLabelUser.Location = New-Object System.Drawing.Size(280,10)
$objLabelUser.Size = New-Object System.Drawing.Size(130,15)
$objLabelUser.BackColor = "Transparent"
$objLabelUser.ForeColor = "yellow"
$objLabelUser.Text = "User Name"
$objForm.Controls.Add($objLabelUser)

#username
$textBoxUser = New-Object System.Windows.Forms.TextBox
$textBoxUser.Location = New-Object System.Drawing.Point(280,30)
$textBoxUser.Size = New-Object System.Drawing.Size(100,20)
$objForm.Controls.Add($textBoxUser)

# password label
$objLabelPass = New-Object System.Windows.Forms.label
$objLabelPass.Location = New-Object System.Drawing.Size(280,50)
$objLabelPass.Size = New-Object System.Drawing.Size(130,15)
$objLabelPass.BackColor = "Transparent"
$objLabelPass.ForeColor = "yellow"
$objLabelPass.Text = "Password"
$objForm.Controls.Add($objLabelPass)

#password
$textBoxPass = New-Object System.Windows.Forms.TextBox
$textBoxPass.Location = New-Object System.Drawing.Point(280,65)
$textBoxPass.Size = New-Object System.Drawing.Size(100,20)
$objForm.Controls.Add($textBoxPass)

# ok button
$objButton = New-Object System.Windows.Forms.Button
$objButton.Location = New-Object System.Drawing.Size(160,100)
$objButton.Size = New-Object System.Drawing.Size(75,23)
$objButton.Text = "OK"
$objButton.Add_Click($button_click)
$objForm.Controls.Add($objButton)
 
# return status
$returnStatus = New-Object System.Windows.Forms.label
$returnStatus.Location = New-Object System.Drawing.Size(8,70)
$returnStatus.Size = New-Object System.Drawing.Size(130,30)
$returnStatus.BackColor = "Transparent"
$returnStatus.Text = ""
$objForm.Controls.Add($returnStatus)
 
# action item here - you could add your own actions
$button_click =
{
 
    $returnStatus.Text = ""
    $objStatusBar.Text = "Checking status..."
 
    $selectedDomain = $listBoxDomain.SelectedItem
    $selectedAction = $listBoxAct.SelectedItem
    $userName = $textBoxUser.Text
    $password = $textBoxPass.Text
    $remoteServer = $domainHash[$selectedDomain]

    #check selection
    if (($selectedDomain -eq $null) -or ($selectedAction -eq $null) -or $selectedAction.Contains("="))
    {
        #show error message
        $objStatusBar.Text = "Please select Domain and Action and try again"
    }
    elseif (($userName -eq "") -or ($password -eq ""))
    {
        #show error message
        $objStatusBar.Text = "Please enter user name and password for the selected domain"        
    }   
    else
    {
        switch -Exact ($selectedAction)
        {
            'Local Admins & RDP Users'
                {
                    # Create a credential object
                    $Credential = New-Object System.Management.Automation.PSCredential -ArgumentList $userName, $(ConvertTo-SecureString $password -AsPlainText -Force)

                    # Create a remote session to the server
                    $Session = New-PSSession -ComputerName $remoteServer -Credential $Credential

                    # Import the remote session
                    # Import-PSSession $Session -AllowClobber
                    Enter-PSSession $Session

                    # Define the script to run on the remote server
                    $Script = {
                        $sharedFolder = "C:\temp"
                        $serverList = $sharedFolder + "\Servers.txt"
                        $outputFile = $sharedFolder + "\Local_Admin_RDP_Users.csv"
                        $errorFile  = $sharedFolder + "\Errors.csv"                        

                        # init 
                        $i = 0
                        $percentage = 0    
                        $totalServers = (Get-Content $serverList | Measure-Object -Line).Lines

                        # Create file (override if exists) and add header
                        Set-Content -Path $outputFile -Value '"Group","Domain","Users","Computer"' -Encoding Unicode
                        Set-Content -Path $errorFile -Value '"Computer","Error"' -Encoding Unicode
                        # loop through each server in the list
                        foreach($computerName in Get-Content $serverList) {                
                            try
                            {           
                                # List all local Admins and Remote Users
                                $groups = Get-WmiObject win32_groupuser –computer $computerName   
                                $groups = $groups | Where-Object { ($_.groupcomponent –match 'Administrators') -or ($_.groupcomponent –match 'Remote')}  
                                $groups | ForEach-Object {                                 
                                    $_.groupcomponent –match "Name\=(.+)$" > $nul  # get group name
                                    $values = """" + $matches[1].trim('"') + """,""" 
                                    $_.partcomponent –match ".+Domain\=(.+)\,Name\=(.+)$" > $nul  # get user domain and user name
                                    $values = $values + $matches[1].trim('"') + """,""" + $matches[2].trim('"') + """,""" + $computerName + """" # concatenate all and add computer name
                                    $values | Out-File -FilePath $outputFile -Append -Encoding Unicode # save to file
                                }
                            }
                            catch   
                            {
                                #Write to console
                                $lastError = $Error[0].ToString()
                                Write-Host $computerName $lastError -NoNewline             
                                #remove new line from the end of the string
                                $lastError = $lastError.TrimEnd("`r?`n") 
                                # Write to errors file 
                                """$computerName"",""$lastError""" | Out-File -FilePath $errorFile -Append
                            }    
                            # calculate percent complete
                            $i = $i + 1
                            $percentage = [math]::Round((($i / $totalServers) * 100))
                            Write-Host "Percentage complete..." $percentage "%"
                        } 
                    }

                    # Run the script on the remote server 
                    Invoke-Command -Session $Session -ScriptBlock $Script 

                    # Remove the remote session
                    Remove-PSSession $Session
                }
            'Window Updates'
                {
                    # Create a credential object
                    $Credential = New-Object System.Management.Automation.PSCredential -ArgumentList $userName, $(ConvertTo-SecureString $password -AsPlainText -Force)

                    # Create a remote session to the server
                    $Session = New-PSSession -ComputerName $remoteServer -Credential $Credential

                    # Import the remote session
                    # Import-PSSession $Session -AllowClobber
                    Enter-PSSession $Session

                    # Define the script to run on the remote server
                    $Script = {
                        $sharedFolder = "C:\temp"
                        $serverList = $sharedFolder + "\Servers.txt"
                        $outputFile = $sharedFolder + "\Windows_Updates.csv"
                        $errorFile  = $sharedFolder + "\Errors.csv" 
                        
                        # init 
                        $i = 0
                        $percentage = 0    
                        $totalServers = (Get-Content $serverList | Measure-Object -Line).Lines

                        # Create file (override if exists) and add header
                        Set-Content -Path $outputFile -Value '"PSComputerName","InstalledOn","Description","HotFixID","InstalledBy"' -Encoding Unicode
                        Set-Content -Path $errorFile -Value '"PSComputerName","Error"' -Encoding Unicode
                        # loop through each server in the list
                        foreach($computerName in Get-Content $serverList) {                
                            try
                            {
                                # Get the latest update by sorting Decending and take Top 1    
                                Get-Wmiobject -ComputerName $computerName -class win32_quickfixengineering | Sort-Object InstalledOn –Descending | Select-Object -First 1 | Select-Object –Property PSComputerName,InstalledOn,Description,HotFixID,InstalledBy | ConvertTo-Csv -NoTypeInformation | Select -Skip 1 | Out-File -FilePath $outputFile -Append
                                # Get local users
                                Get-WmiObject -ComputerName $computerName -Class Win32_UserAccount -Filter "LocalAccount=True" | Select Name, Status, Disabled, AccountType, Lockout, PasswordRequired, PasswordChangeable | ConvertTo-Csv -NoTypeInformation | Select -Skip 1 | Out-File -FilePath $outputFile -Append
                            }
                            catch   
                            {
                                #Write to console
                                $lastError = $Error[0].ToString()
                                Write-Host $computerName $lastError -NoNewline             
                                #remove new line from the end of the string
                                $lastError = $lastError.TrimEnd("`r?`n") 
                                # Write to errors file 
                                """$computerName"",""$lastError""" | Out-File -FilePath $errorFile -Append
                            }    
                            # calculate percent complete
                            $i = $i + 1
                            $percentage = [math]::Round((($i / $totalServers) * 100))
                            Write-Host "Percentage complete..." $percentage "%"
                        }
                    }

                    # Run the script on the remote server 
                    Invoke-Command -Session $Session -ScriptBlock $Script 

                    # Remove the remote session
                    Remove-PSSession $Session
                }
            'View Report'
                {
                    Write-Host "Not implemented"
                }
        }

        $objStatusBar.Text = "Done"
    }

    # output - online
    #if (Test-Connection $computerName -quiet -Count 2){
    #    Write-Host -ForegroundColor Green "$computerName is online"
    #    $returnStatus.BackColor = "Transparent"
    #    $returnStatus.ForeColor = "lime"
    #    $returnStatus.Text = "Status: Online"
    #}
    #Else{
    # output - offline
    #    Write-Host -ForegroundColor Red "$computerName is offline"
    #    $returnStatus.ForeColor= "Red"
    #    $returnStatus.Text = "Status: Offline"
    #}    
 
}
 
# form status bar
$objStatusBar = New-Object System.Windows.Forms.StatusBar
$objStatusBar.Name = "statusBar"
$objStatusBar.Text = "Ready"
$objForm.Controls.Add($objStatusBar)
 
$objForm.Add_KeyDown({if ($_.KeyCode -eq "Enter"){$button_click}})
$objForm.Add_KeyDown({if ($_.KeyCode -eq "Escape"){$objForm.Close()}})
 
# modal
$objForm.Topmost = $True
$objForm.Add_Shown({$objForm.Activate()})
[void] $objForm.ShowDialog()