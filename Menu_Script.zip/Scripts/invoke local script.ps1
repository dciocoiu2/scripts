

                    # run the script
                    $scriptPath = @(Join-Path -Path "." -ChildPath "ListLocalAdminAndRemoteUsers.ps1")
                    $scriptPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($scriptPath)
                    $argumentList = @("-domainName " + "'" + $selectedDomain + "'")

                    #Write-Host "Attempting new session with: $scriptPath $argumentList"
                    #$session = New-PSSession -ComputerName "localhost" -Name "mySession"
                    #$Job = Invoke-Command -Session $session -FilePath "$scriptPath $argumentList" -AsJob
                    #Wait-Job -Job $Job

                    Write-Host "Attempting to invoke-expression with: $scriptPath $argumentList"
                    $strRemoteServerFQDN = "localhost"
                    Invoke-Command -ComputerName $strRemoteServerFQDN -FilePath $scriptPath -ArgumentList $argumentList
                    #Invoke-Expression -Command "$scriptPath $argumentList"
                    Write-Host "Invoked."