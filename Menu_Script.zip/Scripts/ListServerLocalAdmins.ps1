﻿# Get a list of the local admins from a provided list of servers
# Usage:
# >     .\ListServerLocalAdmins -serverList '.\Servers.txt' -outputFile ".\LocalAdmins.csv" -errorFile ".\Errors.csv"
#
#

Param
(  
    [CmdletBinding(SupportsPaging = $true)]
    [Parameter(Mandatory=$false)]
    [String]
    $serverList = ".\Servers.txt",
    $outputFile = ".\LocalAdmins.csv",
    $errorFile = ".\Errors.csv"
) 

Begin
{
    # init 
    $i = 0
    $percentage = 0    
    $totalServers = (Get-Content $serverList | Measure-Object -Line).Lines
}

Process
{
    # Create file (override if exists) and add header
    Set-Content -Path $outputFile -Value '"PSComputerName","Name"' -Encoding Unicode
    Set-Content -Path $errorFile -Value '"PSComputerName","Error"' -Encoding Unicode
    # loop through each server in the list
    foreach($computerName in Get-Content $serverList) {                
        try
        {           
            # List all local Admins
            $admins = Get-WmiObject win32_groupuser –computer $computerName   
            $admins = $admins |? {$_.groupcomponent –like '*"Administrators"'}  
            $admins | ForEach-Object {                 
                $_.partcomponent –match ".+Domain\=(.+)\,Name\=(.+)$" > $nul  
                """" + $computerName + """,""" + $matches[1].trim('"') + "\" + $matches[2].trim('"') + """" | Out-File -FilePath $outputFile -Append
            }
        }
        catch   
        {
            #Write to console
            $lastError = $Error[0].ToString()
            Write-Host $computerName $lastError -NoNewline             
            #remove new line from the end of the string
            $lastError = $lastError.TrimEnd("`r?`n") 
            # Write to errors file 
            """$computerName"",""$lastError""" | Out-File -FilePath $errorFile -Append
        }    
        # calculate percent complete
        $i = $i + 1
        $percentage = [math]::Round((($i / $totalServers) * 100))
        Write-Host "Percentage complete..." $percentage "%"
    } 
}

End
{
    # cleanup
}